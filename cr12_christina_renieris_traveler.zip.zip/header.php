<!DOCTYPE html>
<html <?php language_attributes(); ?>>
 <head>
   <meta charset="<?php bloginfo('charset'); ?>">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="<?php bloginfo('description'); ?>">
   
    <!--If its front page then show blog-info if not then page tittle-->
   <title>
        <?php bloginfo('name'); ?> |
        <?php is_front_page() ? bloginfo('description') : wp_tittle(); ?>
        <?php wp_title(); ?> 
   </title>
    <!--Getting current page title -->

   <!-- Bootstrap core CSS -->
    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet"><!--URL of the active theme's directory-->
    <!-- Custom styles for this template -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_url' ); ?>style.css" />
    <!--Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <?php wp_head(); ?>

  </head>
 <body>
    <nav class="navbar navbar-expand-md navbar-light bg-info" role="navigation" id="navi">

        <div class="container">

            <!-- Brand and toggle get grouped for better mobile display -->

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-controls="bs-example-navbar-collapse-1" aria-expanded="false" aria-label="Toggle navigation">

                <span class="navbar-toggler-icon"></span>

            </button>

            <a class="navbar-brand" href="index.php">Home</a>

            <?php

                wp_nav_menu( array(

                    'menu' => 'primary',

                    'theme_location'    => 'primary',

                    'depth'             => 2, // 1 = no dropdowns, 2 = dropdown

                    'container'         => 'div',

                    'container_class'   => 'collapse navbar-collapse',

                    'container_id'      => 'bs-example-navbar-collapse-1',

                    'menu_class'        => 'nav navbar-nav',

                    'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',

                    'walker'            => new WP_Bootstrap_Navwalker()

                ) );

            ?>

        </div>

    </nav>

<div class="container">
     <div class="blog-header">
       <h1 class="blog-title"><?php bloginfo('name'); ?></h1>
       <p class="lead blog-description"><?php bloginfo('description'); ?></p>
     </div>
     <section class="showcase">
    <div class="container">
      <h1>Custom Traveler Wordpress Theme</h1>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
      <a class="btn btn-primary btn-lg">Read More</a>
    </div>
  </section>