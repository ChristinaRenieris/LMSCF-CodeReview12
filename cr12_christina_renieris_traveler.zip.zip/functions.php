<?php 
    require_once('WP_Bootstrap_Navwalker.php');

    function wpb_theme_setup(){
        add_theme_support('post-thumbnails');
        register_nav_menus(array('primary' => __('Primary Menu') ));
    }
    add_action('after_setup_theme','wpb_theme_setup');

    function set_excerpt_length(){
        return 30;
    }

    add_filter('excerpt_length', 'set_excerpt_length');

    function codefactory_files() {
        wp_enqueue_style( 'bootstrap-css', get_template_directory_uri() . '/css/bootstrap.css' );
        wp_enqueue_style( 'style-css', get_template_directory_uri() . '/style.css' );
        wp_enqueue_script( 'bootstrap-js', get_template_directory_uri() . '/js/bootstrap.js', array(), true );
        }
        add_action( 'wp_enqueue_scripts', 'codefactory_files' );

        
?>